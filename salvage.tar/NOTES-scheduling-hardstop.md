# SCHEDULING NOTE (orchestrator, 2026-10-31 ~07:20Z)

The executor hard-stops EVERY run at 4h (RuntimeMaxSec=14400 backstop, warden-confirmed by-design; wall_timeout is advisory and never kills). THIS RUN'S HARD STOP: ~11:09Z (10:09pm AEDT). The 6h budget line in the brief is void.

Priority order if running long:
1. clean probe (2 consecutive runs, sane tokens)
2. lossless gates (14-tok + 4096-tok, byte-identical)
3. A/B bench (the number)
4. PR
After ~09:00Z, stop starting new debug cycles. Instead: commit state to a branch, push mirror ref fleetwork-salvage/1079, write REPORT.md with the exact next step, exit. A dirty wall-kill is survivable; a pushed salvage ref + report makes the re-roll 10 minutes instead of 4 hours.
