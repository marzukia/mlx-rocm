# ROCm/HIP & CUDA graph-capture memory pitfalls: the stale/aliased-memory class

Research date: 2026-07. Target: gfx1201 (RX 9070 XT / Radeon AI PRO R9700), ROCm 10.1 userland
(TheRock 10.1, HIP 7.16.0), qMLX exec-caching path (capture once → per-step H2D into a stable
input slot → `hipGraphLaunch` per decode step).

- **Symptom 1 (fixed):** `HSA_STATUS_ERROR_MEMORY_FAULT` on 2nd-capture replay; arena reset
  re-allocated INTO the input slot, aliasing a gather output with the idx buffer.
  Fix: `decode_arena_freeze_floor` / `reset_to_floor` instead of `reset` (vendor
  `mlx/backend/rocm/allocator.cpp:893-909`).
- **Symptom 2 (open):** with exec caching, replay reads STALE input (garbage tokens, no fault).

Key framing: "stale" has two distinct mechanisms — **(a) device data** in the input slot is not
fresh at replay time (ordering/coherence bug), vs **(b) the pointer/VA baked into the graph's
AQL packet** is stale or the packet update silently failed. The evidence below ranks which is
more likely.

---

## 1. Ranked candidate root causes for Symptom 2

1. **H2D not ordered before the graph launch on the executing queue (ordering bug in the
   captured/launched path).** Strongest match. Open upstream bugs show the exact failure on
   this GPU class:
   - ROCm/HIP #3902 — graph replay reads one-epoch-old device buffer on gfx950, H2D on a
     (default) stream before replay, no error, Heisenbug. Same shape as ours.
     https://github.com/ROCm/HIP/issues/3902
   - ROCm/rocm-systems #11403 — an **uncaptured SDMA memcpy** (i.e. a plain `hipMemcpyAsync`
     H2D) is dispatched on its own copy engine, outside the graph's dependency chain; it takes
     a *positional* wait from the signal pool, and a retired signal is **dropped rather than
     waited on, so the copy can have no wait at all** → "reads its source before the producer
     has written it" / stale data. Open.
     https://github.com/ROCm/rocm-systems/issues/11403
   - ROCm/rocm-systems #13877 — on **gfx1201 (R9700)**, a `D2H → WRITE(default) → CPU
     acquire/read` sequence is not equivalent after the dispatch-scope change: the notification
     can be observed before the data. Open.
     https://github.com/ROCm/rocm-systems/issues/13877
   - ROCm/rocm-systems #13275 (fixed) — **H2D staging race on RX 9070 XT, our exact GPU**:
     staging copies did a CPU `memcpy` from `hostSrc` before the pending `hipLaunchHostFunc`
     finished writing → **H2D copies stale data**; was 0-12/100 correct on the 9070 XT before
     the fix. If a similar path (shader-blit/staged H2D) is still unguarded in 10.1, this is a
     direct candidate.
     https://github.com/ROCm/rocm-systems/pull/13275
   - ROCm/HIP #3882 — D2D memcpy node dependencies **not enforced on the first launch after
     `hipGraphInstantiate`**; dependent kernel reads stale data; "subsequent launches execute
     correctly". Workaround named in the issue: use a kernel-based copy instead of the memcpy
     node. Open (gfx908, but same CLR path).
     https://github.com/ROCm/HIP/issues/3882
   - ROCm/clr #279 — nondeterministic replay corruption on MI300X, bisected to CLR graph
     commits ("reduce latency before first graph packet", signal-pool sizing, "fix memory
     address offset bug") between 7.1.1 and 7.2.0. Open; evidence the CLR packet/signal path
     has had real stale-data-class regressions.
     https://github.com/ROCm/clr/issues/279

2. **Silent `hipGraphExecUpdate` / `ExecNodeSetParams` failure → the exec keeps the previous
   (stale) AQL packet, API still reports success.** The "re-point node arg params via
   `hipGraphExecKernelNodeSetParams"` workaround exercises exactly this path:
   - ROCm/rocm-systems #10714 (PR, open): at the therock-7.14 tag, `hipGraphExecUpdate`'s bulk
     loop assigns `UpdateAQLPacket()`'s error without checking it and falls through to
     `HIP_RETURN(hipSuccess)`. "The API reports success while the exec keeps the previously
     captured packet … silent wrong output."
     https://github.com/ROCm/rocm-systems/pull/10714
     (Current `develop` of rocm-systems checks the status and returns
     `hipErrorGraphExecUpdateFailure`; **verify whether ROCm 10.1 / HIP 7.16.0 has the
     check** — our guest may predate it.)
   - Related: #10021 (SIGSEGV in kernarg capture under device-memory exhaustion),
     #10713 / #11434 / #14011 (kernarg staging slots never reclaimed within an exec's
     lifetime; ~exhaustion every ~4.1k updates; "reuse GraphExec kernarg slots on
     hipGraphExecUpdate" — all open). If our per-step param updates exhaust/stage kernarg
     slots, the new packet update can fail silently → stale pointer or stale args.
     https://github.com/ROCm/rocm-systems/issues/10021
     https://github.com/ROCm/rocm-systems/issues/10713
     https://github.com/ROCm/rocm-systems/issues/11434
     https://github.com/ROCm/rocm-systems/issues/14011

3. **VA/pointer staleness from reallocation (the Symptom-1 mechanism, uncaught in a second
   slot).** Upstream fixed the *replay* variant for the HRR tooling, which documents the
   mechanism:
   - ROCm/rocm-systems #13106 / #13186 (fixed, closed): "Replay gives every allocation a new
     address. A kernel that reads a device address the application stored in memory, not
     passed as a kernel argument, then reads the capture-time address and faults." Fix:
     place replay allocations at the recorded address (VMM). Also documents a **gfx1201
    -specific twist**: "on gfx1201 … `hipMemUnmap` leaves the old GPU translation cached, so
     memory mapped next at the same address is reached through the pages it replaced"
     (TLB/translation staleness — a workaround allocates/frees 4 MiB to force a KFD TLB
     flush). If any non-input buffer's VA can move between captures while a kernel derefs a
     *stored* pointer, this is the failure mode.
     https://github.com/ROCm/rocm-systems/pull/13106
     https://github.com/ROCm/rocm-systems/pull/13186
   - ROCm/HIP #3887 — "stale device-pointer values on gfx1201" (~200-node graph, same
     device-pointer + `hipMemcpyAsync` pattern as ours). AMD could not reproduce; user's root
     cause was "a bug in our graph-capture setup". Useful negative evidence: the plain
     pattern is not broken per se on gfx1201 ROCm 7.2.2.
     https://github.com/ROCm/HIP/issues/3887

4. **Captured pool free semantics** (only if we ever capture `hipFreeAsync`/trims): in
   non-VM pools, a captured free returns memory to the pool **at capture time**, so the VA can
   be re-allocated before replay (virtual aliasing → silently reads/writes another
   allocation's data). CUDA docs state the same for `cudaFreeAsync`. Low likelihood for the
   current design (arena is static; frees are not captured) but it is the class behind
   Symptom 1 and must stay out of the captured region.
   - Source: `projects/clr/hipamd/src/hip_mempool.cpp` — `hipMallocAsync`/`hipFreeAsync` are
     `STREAM_CAPTURE`'d into graph memAlloc/memFree nodes; `hipMemPoolTrimTo` has **no**
     capture-mode check. https://github.com/ROCm/rocm-systems/blob/develop/projects/clr/hipamd/src/hip_mempool.cpp
   - ROCm/HIP #13627 — double-free of a graph mem-free node returns `hipSuccess` (Windows
     gfx110X). https://github.com/ROCm/rocm-systems/issues/13627

5. **Lower-likelihood but gfx1201/ROCm-10.1-adjacent:**
   - ROCm/rocm-systems #12638 — ROCm 10: captured *empty* graph segment reserves a completion
     signal without a producer → fork/join replay **hangs** on first replay.
     https://github.com/ROCm/rocm-systems/issues/12638
   - ROCm/rocm-systems #13246 — gfx1201, ROCm 10.1 SDK: repeated `hipGraphLaunch` randomly
     corrupts the heap inside `hipStreamSynchronize` (open; Windows, but same ASIC/driver
     class). https://github.com/ROCm/rocm-systems/issues/13246
   - ROCm/rocm-systems #12330 — gfx1201: graph branches serialized on ROCm 10.0.0 (perf, not
     correctness). https://github.com/ROCm/rocm-systems/issues/12330
   - ROCm/rocm-systems #14061 — `hipGraphInstantiate`/`ExecUpdate`/`Exec*SetParams` leave the
     null stream fence-dirty → extra system-scope barrier on every later eager launch (perf,
     also means our param-update path has side effects on the null stream).
     https://github.com/ROCm/rocm-systems/pull/14061

---

## 2. Q1 — HIP graph × memory pool / `hipMallocAsync`: constraints & known bugs

**Source-level semantics (rocm-systems `develop`, verify per 7.16.0):**
- `hipMallocAsync`/`hipFreeAsync` on a capturing stream become graph memAlloc/memFree nodes
  (`STREAM_CAPTURE` in `hip_mempool.cpp:96,159,369`). Physical memory is *not* allocated at
  capture; it is acquired at launch (same as CUDA: "physical memory cannot be allocated or
  mapped at graph instantiation; mapping is at graph launch").
- **Non-VM pools** (default, `HIP_MEM_POOL_USE_VM` unset): a captured `hipFreeAsync` returns
  the block to the pool **at capture time**, so the VA can be handed out again before the
  graph runs. If a captured kernel later writes that VA, and a captured memAlloc re-uses it
  for another node, you get virtual aliasing (silent cross-talk, no fault) — the exact class
  of Symptom 1.
- `hipMemPoolTrimTo` has no capture check: trimming inside a capture changes the *current*
  pool, and the *next launch* of the graph remaps physical memory (CUDA doc: "remaps
  physical memory on next launch"). Trim-while-refs-alive ⇒ possible fault or silent
  re-mapping under a live exec.
- Graph memory-node alloc only allows `hipMemAllocationTypePinned` + device location
  (`hipGraphAddMemAllocNode` parameter check, `hip_graph.cpp` around line 2945).
- ROCm 7.0+ stream capture is **Restricted mode only** (rocm-7.0/7.14 release notes; CUDA
  parity: restricted allows the async mem-alloc APIs but *not* the sync ones; several APIs
  return "operation not permitted when stream is capturing", e.g. RCCL collectives,
  ROCm/RCCL #2022).

**Known bugs in this area (with URLs):**
- #3902 (open, gfx950): stale H2D data on graph replay, Heisenbug — the closest public match
  to our Symptom 2.
- #11403 (open): uncaptured SDMA memcpy in a graph has no reliable wait on the compute
  queue's writes (positional signal lookup; retired signal dropped) → stale source reads.
- #11662 (open, gfx908): `hipMemcpyBatchAsync` D2H stores racing a graph replay corrupt
  device memory, no API error, layout-dependent.
- #10021 / #10713 / #11434 / #14011: kernarg staging pool never reclaims slots within an
  exec lifetime; ~exhaustion every ~4.1k updates; SIGSEGV under exhaustion.
- #13627: double-free of graph mem-free node returns success (Windows gfx110X).
- #14451: `hipGraphInstantiate` runs a managed-memory `hipMemcpy2DAsync` node immediately and
  `hipGraphLaunch` then executes nothing (gfx1151, ROCm 7.1).
- #12638: ROCm 10 empty-segment signal hang (fork/join).
- #13106/#13186 (fixed): replay VA re-assignment; + the gfx1201 `hipMemUnmap` stale
  translation (TLB) quirk.
- #13275 (fixed): H2D staging race — RX 9070 XT explicitly in the test table.
- #12677: synchronous `hipMemset` on one thread invalidates a *thread-local* capture on a
  non-blocking stream of another thread (multi-threaded stacks: our serve process is
  single-threaded on the stream, but worth noting).

---

## 3. Q2 — `hipGraphExecUpdate` semantics & pitfalls

From `rocr-runtime`/`projects/clr/hipamd/src/hip_graph.cpp` (develop; 7.14-era per #10714):

1. **Positional topological pairing.** `hipGraphExecUpdate` pairs new-graph nodes to the
   exec's nodes **by topological order** (`GetUpdateTopoOrder()`): node count must match,
   per-node type must match, memcpy node kind must match, device must match, and
   `HasMatchingDependencies` must hold in the mapped order. Any mismatch ⇒
   `hipErrorGraphExecUpdateFailure` with `hipGraphExecUpdateErrorTopologyChanged` /
   `ErrorUnsupportedFunctionChange` / `ErrorParametersChanged` / `ErrorNodeTypeChanged`.
   **Pitfall:** adding, removing, or *reordering* nodes (including dependency order of
   unrelated nodes) fails the update; our `exec_pool_` topology key must therefore encode
   order, not just counts — and any per-step change that alters node count (e.g. a
   conditional branch, a new memcpy node) silently forces a fallback path.
2. **Fast path:** if the topology is unchanged, a node's params compare equal, and the node
   doesn't `NeedsRecapture`, the node is skipped; otherwise `SetParams` +
   `UpdateAQLPacket` re-records the node's AQL packet (CLR forms packets by submitting each
   node's commands to the **null stream** in packet-capture mode — see #14061). Kernel args
   are *baked into the packet at that point*; the `kernelParams` array on the host is
   snapshotted, so changing the array later has no effect.
3. **Silent stale packet (the big one, pre-fix):** `UpdateAQLPacket` failure was assigned
   without being checked and the API returned `hipSuccess`, leaving the *previous* packet in
   the exec (#10714, at therock-7.14). Next launch then executes the stale packet → stale
   pointers/args, no error. On our ROCm 10.1 guest: **check the return code of every
   `hipGraphExecUpdate` / `hipGraphExecKernelNodeSetParams` and treat any failure as
   "re-instantiate the exec"** (the CUDA-backend pattern in
   `vendor/.../backend/cuda/device.cpp:515-525` does exactly this: on
   `cudaGraphExecUpdate` failure, `cudaGetLastError(); graph_exec.reset();` then
   re-instantiate).
4. **`GetClonedNode` requirement:** every `hipGraphExec*NodeSetParams` maps the passed node
   via `GetClonedNode(n)` — `n` **must be a node of the exec's original graph**, not a node
   of a freshly-captured graph (or another exec's graph), or the call returns
   `hipErrorInvalidValue`. When "re-pointing node args", pass the node handle from the
   *original* capture, and check the return.
5. **Kernarg pool exhaustion:** each packet update stages kernel args; slots are never
   reclaimed within an exec's lifetime (#10713; fix PRs #11434/#14011 open). Heavy
   per-step `ExecNodeSetParams` on many nodes can exhaust staging → update failure → (3).
6. **Exec lifetime vs launch:** destroying a `hipGraphExec_t` without syncing retains
   references until execution completes (CUDA user-object parity); but a *failed* update
   leaves the exec in the old state, not a partial one.
7. **`hipGraphExecMemcpyNodeSetParams` exists for re-pointing memcpy src/dst VAs** — but a
   memcpy *kind* change (H2D↔D2D) fails the update (`ErrorParametersChanged`), and the
   first-launch memcpy-dependency bug (#3882) means memcpy nodes are the fragile kind.

---

## 4. Q3 — CUDA-side analogues & the named workarounds

**CUDA Programming Guide (Release 13.4, docs.nvidia.com) — the exact semantics HIP copies:**
- Graph memory nodes: "allocations persist beyond graph execution if not freed by the graph";
  "physical memory cannot be allocated or mapped at graph instantiation time; mapping is at
  graph launch"; `cudaMemPoolTrimTo` "remaps physical memory on the next launch".
- **Virtual aliasing warning (the canonical wording of our failure class):** "erroneous access
  may silently read or write live data owned by another allocation."
- `cudaGraphExecUpdate` pairing rules: same API-call order, same edge-spec order, consistent
  sink-node ordering (→ the same positional/topological pairing as HIP).
- `cudaStreamWaitEvent` is the named mechanism for cross-stream ordering; "input borrow"
  (stable device buffer + per-step H2D) is only safe if the H2D is ordered before the graph
  launch on the same stream, or joined via event record/wait (cudaEventRecord on the
  H2D stream, cudaStreamWaitEvent on the launch stream).

**Named CUDA-side analogues of our two symptoms:**
- *Symptom 1 analogue:* `cudaFreeAsync` + `cudaMallocFromPoolAsync` under capture: the pool
  may hand the VA back before the graph runs; the canonical workaround is the **stable
  arena** (pre-allocated device buffer carved per-step, `cudaFreeAsync` never captured —
  the llama.cpp `--cuda-graph` / MLX buffer-cache pattern, ml-explore/mlx #2358), plus
  setting pool release thresholds so the pool doesn't shrink mid-graph
  (`cudaDeviceSetMemPoolAttr(release_threshold, UINT64_MAX)`), and never trimming the pool
  while an exec is alive.
- *Symptom 2 analogue:* (a) **ordering** — H2D on a different stream than the graph launch
  with no event join is the #1 named cause in NVIDIA forums; fix: same stream, or
  `cudaEventRecord`/`cudaStreamWaitEvent`. (b) **stale baked pointer** —
  `cudaGraphExecUpdate`/`cudaGraphExecKernelNodeSetParams` failure while keeping the old
  exec; fix: check `cudaGraphExecUpdate` result, on failure re-instantiate (upstream MLX
  does exactly this, `backend/cuda/device.cpp:515-525`). (c) **VA move under a stored
  pointer** — keep all device pointers inside the stable arena; never re-`cudaMalloc` a
  buffer a captured kernel dereferences.

---

## 5. Q4 — MLX-specific CUDA/HIP graph decode work

**Upstream ml-explore/mlx (CUDA backend, the pattern our ROCm port mirrors):**
- #2317 "Switch to CUDA graphs" — capture-once, per-commit exec, LRU exec cache keyed by
  node+deps (`graph_cache_` in `backend/cuda/device.cpp`), env toggles
  (`MLX_CUDA_GRAPH_CACHE_SIZE`, #2329; toggle #2545; LRU #2448).
- #2358 / #2359 — buffer cache + `mx.compile`: **address stability via a pre-allocated
  arena** so captured VAs never move (llama.cpp pattern).
- #2883 / #2901 — more graph types marked updatable; host nodes in subgraphs for updates.
- #4326 / #4356 — **a failed graph commit must not poison the encoder** (isolate encoder
  state across commits).
- #4699 / #4700 — **illegal `__global__` write in `copy_s` under CUDA graphs on sm_120
  (consumer Blackwell) → corrupted output**: an allocation/ordering race; fixed by
  **serializing graph kernels** (submission-order chain edges).
- #4745 (merged) / #4697 — **avoid multi-root graphs on DGX/RTX Spark** (single dummy root
  kernel); serialize graph kernels on DGX Spark.
- No upstream ROCm backend (only open experiments #2300/#2556) — **the graph decode work on
  AMD is ours**: `vendor/.../backend/rocm/device.cpp` (exec_pool_ keyed by topology,
  `hipStreamBeginCapture` child-graph fallback, **submission-order chain edges already
  present** — the #4699 fix ported), plus the decode arena in `allocator.cpp`.

---

## 6. Workarounds worth testing (ordered)

Diagnostic first (cheap, discriminates the class):

1. **After the per-step H2D, before `hipGraphLaunch`:** read back the input slot D2H (or a
   tiny checksum kernel) *on the same stream*, and compare to host. If the read-back is
   already stale pre-launch → staging/ordering bug on the H2D path (candidates #13275 /
   #11403 class). If fresh pre-launch but the graph sees stale → in-graph ordering
   (candidates #3882 / #3902 / #11662 class) or stale baked pointer (#10714 class).
2. **Log every `hipGraphExecUpdate` / `hipGraphExecKernelNodeSetParams` return code.** Any
   non-success (especially on a ROCm ≤7.14-era build) ⇒ re-instantiate the exec and log the
   count of failures over time (kernarg exhaustion #10713 shows up as a rising failure rate).
3. **Repoint the input pointer in the graph as a D2D copy** (or as the *value* of a kernel
   arg) instead of an external H2D: i.e., H2D into a stable *staging* slot, then an in-graph
   D2D `hipMemcpyAsync` (or a 2-line copy kernel) into the input slot. If stale-reads
   disappear, the H2D copy-engine path was the culprit. (Same workaround named in #3882.)
4. **Event join across streams** (diagnostic, not production): `hipEventRecord` after the
   H2D on its stream, `hipStreamWaitEvent` on the launch stream. Fixes ordering bugs (1-2)
   at the cost of an event; if it fixes the symptom, the production fix is "do the H2D on
   the launch stream" or "capture the H2D node with a pinned host buffer".

Structural fixes (production):

5. **Route the per-step H2D on the exact stream that launches the graph** (single-stream
   model; no event needed). Cheapest and most robust production fix for the ordering class.
6. **Capture the H2D inside the graph** from a **pinned** host staging buffer (pinned
   reads are DMA-ordered by the signal chain — per #13275 the pinned/SDMA path is the
   ordered one); re-point the memcpy src per step via
   `hipGraphExecMemcpyNodeSetParams` (check the return; kind must stay H2D).
7. **Keep every device pointer a kernel derefs inside the static arena** (input slot,
   weights, idx buffer, gather outputs); never let the pool/arena hand out a VA that a
   captured kernel holds as a stored pointer; keep `hipFreeAsync`/`hipMemPoolTrimTo` out of
   the captured region; set the pool release threshold to `UINT64_MAX` while the exec is
   live (prevents mid-graph shrinking/remapping).
8. **On any `ExecUpdate` failure: re-instantiate** (CUDA-backend pattern), never
   "keep the exec and hope"; also re-check the `GetClonedNode` rule — pass *original*-
   graph node handles to the `SetParams` APIs.
9. If the stale-reads are timing-Heisenbug-shaped (fixes when timing changes): that is the
   signature of #11403/#279-class signal-pool ordering; escalate with the repro to
   rocm-systems and in the meantime use 3-5 (in-graph copy / same-stream H2D).

---

## 7. Source index

- ROCm/HIP #3902 (open) stale replay buffer, gfx950 — https://github.com/ROCm/HIP/issues/3902
- ROCm/HIP #3887 (closed, user error) stale device pointers, gfx1201 — https://github.com/ROCm/HIP/issues/3887
- ROCm/HIP #3888 (closed) exec-update + pitch mismatch — https://github.com/ROCm/HIP/issues/3888
- ROCm/HIP #3882 (open) memcpy-node dep not enforced on first launch — https://github.com/ROCm/HIP/issues/3882
- ROCm/rocm-systems #11403 (open) uncaptured SDMA memcpy ordering — https://github.com/ROCm/rocm-systems/issues/11403
- ROCm/rocm-systems #13877 (open) pre-WRITE publication, gfx1201 — https://github.com/ROCm/rocm-systems/issues/13877
- ROCm/rocm-systems #13275 (merged) H2D staging race, RX 9070 XT — https://github.com/ROCm/rocm-systems/pull/13275
- ROCm/rocm-systems #10714 (open PR) silent stale packet in ExecUpdate — https://github.com/ROCm/rocm-systems/pull/10714
- ROCm/rocm-systems #10021 (open) SIGSEGV kernarg capture under OOM — https://github.com/ROCm/rocm-systems/issues/10021
- ROCm/rocm-systems #10713 / #11434 / #14011 (open) kernarg slot non-reclamation —
  https://github.com/ROCm/rocm-systems/issues/10713
  https://github.com/ROCm/rocm-systems/issues/11434
  https://github.com/ROCm/rocm-systems/issues/14011
- ROCm/rocm-systems #11662 (open) D2H stores racing graph replay, gfx908 — https://github.com/ROCm/rocm-systems/issues/11662
- ROCm/rocm-systems #12638 (open) ROCm 10 empty-segment signal hang — https://github.com/ROCm/rocm-systems/issues/12638
- ROCm/rocm-systems #13246 (open) gfx1201 ROCm 10.1 graph-launch heap corruption — https://github.com/ROCm/rocm-systems/issues/13246
- ROCm/rocm-systems #12330 (open) gfx1201 graph branches serialized — https://github.com/ROCm/rocm-systems/issues/12330
- ROCm/rocm-systems #14061 (open PR) null-stream fence dirty after graph updates — https://github.com/ROCm/rocm-systems/pull/14061
- ROCm/rocm-systems #13106 / #13186 (merged) replay VA placement + gfx1201 TLB quirk —
  https://github.com/ROCm/rocm-systems/pull/13106
  https://github.com/ROCm/rocm-systems/pull/13186
- ROCm/rocm-systems #13627 (closed) graph mem-free node double-free success — https://github.com/ROCm/rocm-systems/issues/13627
- ROCm/rocm-systems #14451 (open) instantiate runs managed-mem memcpy node immediately — https://github.com/ROCm/rocm-systems/issues/14451
- ROCm/rocm-systems #12677 (open) cross-thread capture invalidation — https://github.com/ROCm/rocm-systems/issues/12677
- ROCm/clr #279 (open) nondeterministic replay corruption, MI300X, 7.2.0 bisect — https://github.com/ROCm/clr/issues/279
- ROCm/RCCL #2022 (collectives under capture) — https://github.com/ROCm/rccl/issues/2022
- Source: `projects/clr/hipamd/src/hip_graph.cpp` (ExecUpdate/GetClonedNode/UpdateAQLPacket) —
  https://github.com/ROCm/rocm-systems/blob/develop/projects/clr/hipamd/src/hip_graph.cpp
- Source: `projects/clr/hipamd/src/hip_mempool.cpp` (STREAM_CAPTURE memAlloc/memFree) —
  https://github.com/ROCm/rocm-systems/blob/develop/projects/clr/hipamd/src/hip_mempool.cpp
- CUDA Programming Guide (13.4): graph memory nodes, virtual aliasing, ExecUpdate pairing,
  stream-wait-event — https://docs.nvidia.com/cuda/cuda-programming-guide/index.html
- ml-explore/mlx #2317 #2358 #2359 #2329 #2448 #2883 #2901 #4326 #4356 #4697 #4699 #4700 #4745 #2300 #2556
- Local: `vendor/mlx-rocm-upstream/mlx/backend/rocm/{device,allocator}.cpp`,
  `vendor/mlx-rocm-upstream/mlx/backend/cuda/device.cpp` (exec-cache pattern)

Notes on tooling: search engines and forums.developer.amd.com were unreachable from the build
host (DNS); findings are from GitHub (ROCm/HIP, ROCm/rocm-systems, ROCm/clr, ROCm/rccl,
ml-explore/mlx), the CUDA Programming Guide, and ROCm release notes (TheRock 10.1 → ROCm
Core SDK 10.1.0, HIP 7.16.0 — no graph-memory fixes listed there).
