# RESEARCH — how production LLM decode loops implement CUDA/HIP graph caching (capture once, replay per step)

Method note: no Tavily API key was present in the environment (checked env + config); web search was done
via DuckDuckGo (throttled after a few queries) plus direct fetches of docs, and GitHub code/issue search
(authed `gh`). Auth-walled or 404'd sources are noted inline.

## 1. WHO and HOW — making the per-step token visible to a replayed graph

**Universal invariant (all systems).** Kernel parameters — including device pointers — are *recorded by value
at capture time*; the graph is a closed snapshot. The only ways a per-step input reaches a replay are:
(a) write into a **fixed device VA** (H2D/D2D `copy_` into a pre-allocated static buffer), or (b)
**update the instantiated graph** (`cudaGraphExecUpdate` / `hipGraphExecKernelNodeSetParams`) with the new
pointer. NVIDIA states it explicitly: "all kernel launch configurations and kernel function parameters … are
recorded by value. Whenever any of the configurations and parameters change, the captured graph must be
updated" (NVIDIA blog, "Constructing CUDA Graphs with Dynamic Parameters",
developer.nvidia.com/blog/constructing-cuda-graphs-with-dynamic-parameters/). PyTorch docs: "A captured graph
acts on the same virtual addresses every time it replays … If PyTorch reassigns the memory to new tensors,
the replay can corrupt the values seen by those tensors" (pytorch/pytorch `docs/source/notes/cuda.md`,
"Graph memory management"; pytorch.org/docs/stable/notes/cuda.html).

| System | Mechanism | Citations |
|---|---|---|
| **PyTorch** (`torch.cuda.graph`, `make_graphed_callables`, cudagraph trees) | Static input tensors; caller does `static_input.copy_(data)` (H2D/D2D into the same VA) *before* `g.replay()`; allocations during capture go to a **graph-private memory pool retained by the graph** (never reused by other allocations). Constraints: capture on non-default stream, no `.item()`/host sync, no dynamic shapes/control flow, one capture at a time. | pytorch/pytorch `docs/source/notes/cuda.md` (constraints + memory sections); pytorch.org/tutorials/intermediate/cuda_graphs_tutorial.html; NVIDIA "CUDA Graph Best Practice for PyTorch" (docs.nvidia.com/dl-cuda-graph/latest/torch-cuda-graph/handling-dynamic-patterns.html — static buffer + in-place scalar tensors; padding/bucketing for shapes) |
| **vLLM** | `CUDAGraphWrapper` + `CudagraphDispatcher` keyed by `BatchDescriptor(num_tokens, num_reqs, uniform…)`; **padding to captured sizes** (`cudagraph_capture_sizes`). Static dual CPU-pinned/GPU buffers: `self.input_ids = self._make_buffer(...)` with `copy_to_gpu()` (H2D, non-blocking) + `prepare_inputs_event.synchronize()` before replay (`synchronize_input_prep`). **Paged KV: pre-allocated static KV pool + static block-table tensor updated per step by H2D/D2D** (`BlockTable.commit_block_table` → `copy_to_gpu`; `builder.update_block_table`). One **shared global graph pool** across all graphs (safe: graphs replayed in same order, never concurrent). Explicit documented pitfall: "The previous eager iteration's start_prefetch may have queued H2D copies on copy_stream that the graph's captured events cannot see. Without this, replay could overwrite static buffers while those copies are still in flight." | vllm-project/vllm `docs/design/cuda_graphs.md`; `vllm/compilation/cuda_graph.py` (L198-319, L560-575); `vllm/v1/worker/gpu_model_runner.py` (L749, L1750-1870, L3572-3580); `vllm/v1/worker/block_table.py` (L181); `vllm/platforms/rocm.py` (same `CUDAGraphWrapper` — the ROCm port is just the HIP path of this same code) |
| **SGLang** | `DecodeCudaGraphRunner` owns static `DecodeInputBuffers` (input_ids, positions, seq_lens, req_pool_indices, out_cache_loc — pre-allocated, created at init); per step `execute()` → `load_batch()` → `self.buffers.input_ids[:raw].copy_(forward_batch.input_ids)` etc. (D2D into static buffers); batch **padded to captured buckets** (`get_batch_sizes_to_capture`, `padded_to_bucket`); `num_token_non_padded` as a static scalar tensor. KV = static `req_to_token` pool, per-step `out_cache_loc` copy. | sgl-project/sglang `python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py` (L185-215, L491, L1146-1171, L1930-1955, L2000-2080) |
| **TensorRT-LLM** (torch backend, incl. in-flight batching decode path) | `_create_shared_static_tensors`: static `input_ids`/`position_ids` allocated **once, sized for the largest batch** (or borrowed from engine buffers); `pad_batch` pads to captured bucket; per step `static_tensors["input_ids"][:actual].copy_(input_ids)`, `attn_metadata.kv_lens_cuda[:batch_size].copy_(...)` (static KV-length buffer + per-step length write); position ids staged. Piecewise "breakable" CUDA graphs for attention; spec-decode ragged verify buckets. | NVIDIA/TensorRT-LLM `tensorrt_llm/_torch/pyexecutor/cuda_graph_runner.py` (L288-330, L799, L923-972, L2544-2621); `tensorrt_llm/_torch/pyexecutor/engine/runners/decoder/graphs.py`; `tensorrt_llm/_torch/pyexecutor/breakable_cuda_graph_runner.py` (L162-177, L206-246) |
| **AMD/ROCm ports** | No separate graph layer: PyTorch-ROCm/vLLM-ROCm/SGLang-ROCm run the *same* wrappers on `hipStreamBeginCapture`/`hipGraphExec`. ROCm HIP graph docs add one strict rule: "Synchronous HIP API calls that are implicitly assigned to the default stream are **not permitted while capturing** … This includes `hipMalloc`, `hipMemcpy` and `hipFree`. … replace them with the corresponding asynchronous calls." Also: "parameters can be updated between executions, the graph structure itself cannot change after instantiation" (ExecUpdate pattern). Known ROCm defects below (§4). | ROCm/hip `docs/how-to/hip_runtime_api/hipgraph.rst` (develop branch); `docs/tutorial/graph_api.rst`; vllm `vllm/platforms/rocm.py` |
| **flash-decode** | Not a graph mechanism: a **kernel** — split-K attention over heads/sequence for decode (2 stages: per-split partial attention + merge), used to make 1-token decode compute-bound so graphs are effective. As an ordinary kernel it obeys the same rules (pointers = kernel args, baked at capture). | vllm `vllm/v1/attention/ops/triton_decode_attention.py` (L7-8, L101-190, credit to lightllm `gqa_flash_decoding_stage1/2`) |
| **llama.cpp (ggml)** | Pre-allocated **single large buffer per device** (one `cudaMalloc`/`hipMalloc`, tensors placed inside; grows → realloc → addresses change); graph per subgraph-chunk; tracks every node's **source data pointers + shapes**; on change → `cudaGraphExecUpdate`, on update failure → destroy + re-instantiate. (This is the pattern MLX issue 2358 points at.) | ggml-org/llama.cpp `ggml/src/ggml-cuda/ggml-cuda.cu` (L2900-2960 `ggml_cuda_graph_update_executable`; buffer ctx ~L3440); ggml-org/llama.cpp PR 6766 (merged 2024-05-08) |
| **MLX (CUDA backend)** | Per-commit subgraphs in an **LRU cache keyed by graph *structure*** (node types + cluster dims, *not* pointers), capacity `MLX_CUDA_GRAPH_CACHE_SIZE` (default 400; throws "cache thrashing" when exceeded — #4356 fixed a failed commit poisoning the encoder). If the structure is updatable → **`cudaGraphExecUpdate` on every commit** (new pointers), else re-instantiate; `MLX_CUDA_GRAPH_SERIAL` serializes nodes on consumer Blackwell to fix a captured-allocation ordering race (#4699, `copy_s` illegal write #4700). This is the answer to MLX's core problem: array VAs change every eval, so MLX *updates* the exec instead of relying on stable VAs. | ml-explore/mlx `mlx/backend/cuda/device.cpp` (L20-22, L216-224, L387-460, L560-600 `commit_impl`, `subgraph_to_key`); issues #2358, #4356, #4699, #4700, #4745; PR #2484 (CudaGraph RAII, unmerged, branch `cuda-utils`) |

## 2. FORBIDDEN / known-broken during capture

- **Host sync / blocking readback**: `.item()`, `cudaEventSynchronize`, stream sync during capture (PyTorch
  constraints, `notes/cuda.md`); ROCm: any *synchronous* API implicitly on the default stream —
  `hipMalloc`, `hipMemcpy` (blocking), `hipFree` — is **not permitted** in capture (use the `*Async`
  variants, which are captured as nodes) (ROCm/hip `hipgraph.rst`).
- **Dynamic shapes / allocations**: graph assumes identical size & layout every replay (PyTorch constraints);
  dynamic allocation patterns are "forbidden in CUDA graphs" (NVIDIA dynamic-patterns doc). Allocations during
  capture must come from a **pool retained by the graph** (PyTorch graph-private pool); an arena/pool that is
  *reused after capture* for other tensors will be overwritten — "the replay can corrupt the values seen by
  those tensors" (PyTorch docs); vLLM/SGLang/TRT-LLM all pre-allocate static buffers *before* capture for
  exactly this reason. ROCm's per-exec **kernarg staging pool is bump-only and never reclaims** slots within
  the exec's lifetime (ROCm/rocm-systems #10713) — long-lived execs updated per token exhaust it.
- **In-place aliasing input↔output**: allowed inside one graph, but sharing a pool across graphs means
  "replaying one graph can clobber another graph's outputs unless `clone()` is called" (PyTorch docs);
  PyTorch forum: "A problem about cuda graph when input and output are the same"
  (discuss.pytorch.org/t/…/215715 — auth-gated page, title + context only).
- **Non-captured work**: "No non-captured CUDA work may run in this process while capture is underway"
  (PyTorch); host work is elided on replay.
- **Ordering races**: H2D on a side stream the replay stream doesn't wait on — vLLM documents the failure
  (see §1 citation) and fixes it with an explicit event sync before replay.

## 3. Pointer stability & growing sequences

- Kernel-arg device pointers **must be identical across replays** unless you update the instantiated graph
  (`cudaGraphExecUpdate` / per-node `SetParams`). That is the whole design space: static-VA + copy-in
  (vLLM/SGLang/TRT-LLM/llama.cpp/PyTorch) vs re-instantiate/update (MLX, llama.cpp on shape change).
- **Paged attention / growing KV inside a captured graph**: nobody resizes the KV. The KV pool is
  **pre-allocated at max** (vLLM cache pool; SGLang `req_to_token` pool) and the per-step change is
  *metadata*: block tables, `seq_lens`, `positions`, `out_cache_loc` — all **static buffers updated per step
  by H2D/D2D at the same VA** (vLLM `BlockTable.commit_block_table`; TRT-LLM `kv_lens_cuda` copy).
  **Sequence length is a tensor value, not a shape**: the graph's grid/config is fixed; length-dependent
  work is data-driven (per-request length tensor). Batch size is the only *shape* dimension → handled by
  **padding buckets** (vLLM `cudagraph_capture_sizes`; SGLang `get_batch_sizes_to_capture`; TRT-LLM
  `pad_batch`).

## 4. OUR symptom — replay reads STALE input slot (~1e9 float pattern) despite per-step H2D

Note on the signature: a real 9B-vocab token id (≤ ~152k) read as float32 is ~1e-40 (subnormal). A ~1e9
pattern (int32 ≈ 1.3e9 / float 1.0e9) is *another tensor's data* sitting in the slot — i.e. the replay
read a **different/overwritten region**, not a stale token. Ranked causes:

1. **The input slot's VA moved between capture and replay; the captured kernel still references the
   capture-time pointer.** Bump-arena floor freeze/reset (or any reallocation) shifts the slot; the H2D lands
   at the *new* VA; the replayed kernel reads the *old* VA, which now holds other arena data → ~1e9
   pattern. This is the single most-cited failure mode: PyTorch "same virtual addresses every replay …
   reassigns the memory → corrupts the values seen by those tensors"; NVIDIA "parameters are recorded by
   value"; mlx #2358 ("the memory address of arrays almost always change"); Megatron-LM #7829 ("the graph
   captures the address … assigning a new tensor does not update the captured address … silently corrupt
   activations and generated tokens").
   Sources: pytorch/pytorch `docs/source/notes/cuda.md`; developer.nvidia.com/blog/constructing-cuda-graphs-with-dynamic-parameters/;
   github.com/ml-explore/mlx/issues/2358; github.com/NVIDIA/Megatron-LM/issues/7829.
2. **Arena reset/floor reuse re-allocates the slot to another buffer before the replayed kernel reads it**
   (VA stable, *content* overwritten — e.g. by the async decode queue's tensors between H2D and read). Same
   PyTorch/vLLM static-buffer rationale; MLX #2358's entire premise (stable addresses per graph, else no
   "perfect graph replay"); our own t1071 RCA suspect (memory [188]).
   Sources: pytorch/pytorch `docs/source/notes/cuda.md`; vllm `vllm/compilation/cuda_graph.py` L560-575;
   github.com/ml-explore/mlx/issues/2358.
3. **ROCm-specific: `hipGraphExecUpdate` silent-success / stale-packet.** If the per-step input reaches the
   graph via an exec update, the update path has a known defect: the bulk update loop "assigns
   `UpdateAQLPacket()`'s error to `status` without checking it and falls through to `HIP_RETURN(hipSuccess)`
   … the API reports success while the exec keeps the **previously captured packet**, and the next launch
   executes it: silent wrong output." On top: NULL-write when the bump kernarg pool is exhausted (#10021).
   This yields *exactly* "replay reads stale kernel args" while the API reports success.
   Sources: github.com/ROCm/rocm-systems/issues/10714 (PR), /issues/10713, /issues/10021.
4. **Ordering race: H2D not ordered before the replay's read.** H2D issued on a stream the graph launch
   doesn't wait on (side non-blocking stream, no event; or the H2D was itself *captured* as a memcpy node
   that re-copies from the captured host staging, shadowing the per-step external H2D). HIP extra strictness:
   a blocking `hipMemcpy` on the default stream during capture is an error (must be `hipMemcpyAsync`).
   vLLM's `sync_prev_onload()` comment is the production example of this exact class.
   Sources: ROCm/hip `hipgraph.rst` (develop); vllm `vllm/compilation/cuda_graph.py` L560-575; vllm
   `vllm/v1/worker/gpu_model_runner.py` `synchronize_input_prep`.
5. **gfx1201 / ROCm 10.x graph-executor defects (same arch as our RX 9070 XT).** Known open issues:
   repeated `hipGraphLaunch` **randomly corrupts the heap** on gfx1201 (ROCm 10.1, #13246 — llama.cpp/
   Ollama die without `GGML_CUDA_DISABLE_GRAPHS=1`); independent graph **branches serialized** on the 10.0
   default executor on gfx1201 (#12330); classic executor **dropping cross-stream dependencies** (#11499/
   #11501 — a dropped dependency lets an input-reading kernel run before the H2D memcpy node completes =
   stale read). Workarounds exist (`DEBUG_HIP_GRAPH_CLASSIC_PATH=1` etc.), and #13246's "no effect" list
   (`HIP_GRAPH_MEM_POOL=0`, `DEBUG_HIP_GRAPH_CLASSIC_PATH=1`) is a ready-made bisect for us.
   Sources: github.com/ROCm/rocm-systems/issues/13246, /issues/12330, /issues/11499, /issues/11501.

**Discriminating tests suggested by the above**: (a) read the slot VA *before* the first replay and after
the arena reset — if they differ, cause 1; (b) write a canary (token value + 1) to the slot after the H2D
and `hipStreamSynchronize` before replay — if the canary survives but the model sees 1e9, the kernel is
reading a *different* VA (1/2); (c) set `DEBUG_HIP_GRAPH_CLASSIC_PATH=1` and `AMD_SERIALIZE_KERNEL=3` —
behavior change implicates the gfx1201 executor (5); (d) check `hipGraphExecUpdate`'s result code each step
(3); (e) capture the H2D on the *replay* stream (or add an event) to rule out 4.
