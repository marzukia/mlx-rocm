#!/bin/sh
# run-wrapper.sh <ticket> <agent-home>
#
# The unit execs a per-run PINNED copy of this file: the executor copies
# it to $WT/.fleetwork/run-wrapper.sh at launch (atomic tmp + replace) and
# the argv points at that copy (issue #133, t584 false-fail — bash reads
# scripts lazily by byte offset, so a deploy that cp's over the shared
# /usr/local/lib/fleetwork/run-wrapper.sh while a run is live desynchronized
# the reader and mixed old + new bytes mid-read; the per-run copy is never
# mutated mid-run). This file is self-location-free (no $0 references), so
# the copy is a drop-in.
#
# Main process of the per-ticket transient unit fleetwork-run-<t>.service
# (spec section 3.2). Runs as the agent's own uid (systemd-run --uid). It
# exists for three things a bare `pi` process cannot do: forward stop signals
# (TERM/INT -> pi, 30s grace, kill -9), keep a live token counter readable by
# the (hallmon) executor, and open the session file's read path after exit.
#
# The brief is read from $WT/.fleetwork/brief (written by the executor,
# chowned to the agent, 0600) and passed via $(cat ...) -- argv-visible in
# ps, the accepted residual shared with bg-run (spec section 9.6): briefs
# must not carry secrets.
#
# Exit code = pi's exit code (0 -> completed; non-zero -> failed exit-<rc>;
# 137 -> pi was SIGKILLed, the executor maps it to unclean/signal-9).
# A forwarded stop signal (TERM/INT) overrides a clean pi exit: the
# wrapper exits 128+<sig> (143 for TERM) so the executor maps the stop
# to unclean/signal-<n> — a signal-killed run must not read clean and
# trip the G6 empty-final override (the t16 misclassification).

set -u
T="$1"
AHOME="$2"
# One session-resolution rule, shared with reap.sh and the executor's
# locate_session (the Python form is reattach.py session_dirs): profile
# dir = $AHOME/.pi/agent-worker when it exists, else $AHOME/.pi/agent. pi
# stores sessions under $PI_CODING_AGENT_DIR/sessions/, so every reader of
# the session file must track the profile (round-3: run 12 completed but
# its record parsed "session file not found", 0 tokens -- the profile
# switch moved the storage and the readers did not follow).
# Dispatch runs use the worker profile (no channels/packages: the Discord
# channel extension is the agent-interactive bg runtime and its stale-ctx
# crashes + re-wake loop are meaningless in a dispatch run). Pilot finding:
# run 3 (re-wake loop + teardown crash) and run 7 (stale-ctx after
# compaction, exit-1). No-op when the profile is absent (the export then
# pins pi's own default).
PROFILE_DIR="$AHOME/.pi/agent"
if [ -n "$AHOME" ] && [ -d "$AHOME/.pi/agent-worker" ]; then
  PROFILE_DIR="$AHOME/.pi/agent-worker"
fi
export PI_CODING_AGENT_DIR="$PROFILE_DIR"

umask 007
# FLEETWORK_BASE_DIR / FLEETWORK_PARSE_SESSION: hermetic-test overrides
# (the CI wrapper tests point these at a scratch tree); the defaults are
# the production paths (the deploy lane sets nothing).
BASE_DIR="${FLEETWORK_BASE_DIR:-/srv/fleetwork}"
PARSE_SESSION="${FLEETWORK_PARSE_SESSION:-/usr/local/lib/fleetwork/parse_session.py}"
# FLEETWORK_DETPIPE: hermetic-test override (the CI wrapper tests point
# it at a scratch tree); the default is the production path (the deploy
# lane sets nothing — the detpipe package ships with this directory).
DETPIPE="${FLEETWORK_DETPIPE:-/usr/local/lib/fleetwork/detpipe/detpipe.py}"
WT="$BASE_DIR/work/$T"
ART="$WT/.fleetwork"
mkdir -p "$ART"

# Session dir pre-created 2750 group-fleetwork so the session file pi writes
# into it is group-traversable/readable by hallmon (the agent's home is 700;
# traversal, not file mode, is the wall).
SESS_DIR="$PROFILE_DIR/sessions/--srv-fleetwork-work-${T}--"
mkdir -p "$SESS_DIR" 2>>"$ART/tailer.log"
# G10 (issue #119): preflight ownership probe -- fail fast (<5s),
# classified. t430 (finding 89): EACCES on the session dir (root:root
# onboarding residue) -- pi died exit-1 pre-first-turn, a 5s burn, and
# only a salvage ref remained. The probe runs BEFORE pi launches (the
# prepare phase): (b) the agent's .pi tree must be owned by the agent
# (the running uid) -- root:root onboarding residue is the onboarding
# class; (a) the session dir must be creatable and writable by the agent
# (the mkdir -w probe) -- a root-owned dir the agent cannot write is the
# EACCES class. A probe failure writes the classified terminal marker and
# exits 0 (the marker, not the code, carries the reason -- the executor's
# map_state reads it on the clean-exit path and maps it to failed/<token>);
# pi is never launched and no salvage runs (there is nothing to salvage
# pre-launch).
if [ -d "$AHOME/.pi" ]; then
  PI_TREE_OWNER=$(stat -L -c %u "$AHOME/.pi" 2>/dev/null) || PI_TREE_OWNER=""
  if [ -n "$PI_TREE_OWNER" ] && [ "$PI_TREE_OWNER" -ne "$(id -u)" ]; then
    printf 'onboarding\n' > "$ART/terminal"
    echo "[preflight] .pi tree not agent-owned (owner=$PI_TREE_OWNER, uid=$(id -u)): $AHOME/.pi" >>"$ART/tailer.log"
    exit 0
  fi
fi
if ! touch "$SESS_DIR/.preflight.$$" 2>>"$ART/tailer.log"; then
  printf 'EACCES\n' > "$ART/terminal"
  echo "[preflight] session dir not writable: $SESS_DIR" >>"$ART/tailer.log"
  exit 0
fi
rm -f "$SESS_DIR/.preflight.$$" 2>/dev/null || true
chgrp fleetwork "$SESS_DIR" 2>/dev/null || true
chmod 2750 "$SESS_DIR"

# The agent's own pi: managed 1.3.0 layout first, then the local-bin fallback
# (spec section 7 step 5 standardizes on the managed layout).
PI_BIN="$AHOME/.pi/agent/bin/pi"
[ -x "$PI_BIN" ] || PI_BIN="$AHOME/.local/bin/pi"

# exec-env (spec section 3.2 step 4): the agent's own HOME/PATH, its own
# ~/.pi/agent/{models,auth,settings}.json -- nothing injected by the executor.
HOME="$AHOME"
PATH="/usr/local/bin:/usr/bin:/bin:$AHOME/.local/bin:$AHOME/.pi/agent/bin"
export HOME PATH

# Optional profile flags (--model/--thinking/--tools/--exclude-tools),
# shell-quoted by the executor into $ART/piargs.
PI_EXTRA=""
[ -f "$ART/piargs" ] && PI_EXTRA=$(cat "$ART/piargs")

# Commit identity: prepare wrote $ART/gitenv (shell-sourceable GIT_CONFIG_*
# exports, 0644) — source it before pi launches so the worker's commits
# carry the dispatching agent's identity (env config outranks all file
# config). Missing file = no identity env = the pre-patch behavior (fine
# for runs without gitenv). The post-exit salvage block re-scopes to the
# neutral salvage identity below, overriding whatever this sourced.
if [ -f "$ART/gitenv" ]; then
  . "$ART/gitenv"
fi

# Models.json header templates (e.g. $PI_SESSION_ID) resolve from env at
# provider init — before pi creates the session — so export it here (the
# session id is fixed by the --session-id flag). Pilot finding: run 10
# exit-1 "Failed to resolve provider header X-Switchboard-Session".
export PI_SESSION_ID="fleetwork-$T"

# F109 (issue #170): client-side LLM capture — the pi extension
# (deploy/fleetwork/extensions/fleetwork-capture.ts, auto-discovered from
# the agent-worker profile's extensions dir; the deploy recipe symlinks it
# in) reads these to write $ART/llm-stream.json (the raw stream sidecar);
# the post-exit llm-capture step below assembles $ART/llm-capture.json.
export FLEETWORK_ART="$ART"
export FLEETWORK_TICKET="$T"

# shellcheck disable=SC2086  # PI_EXTRA is executor-generated, shell-quoted
"$PI_BIN" -p "$(cat "$ART/brief")" --session-id "fleetwork-$T" $PI_EXTRA &
PI=$!

# Token tailer: cumulative {tokens, turns, cost (price sheet), wall} every
# 20s to live.json -- the executor's monitor loop reads it for budgets.
# --pi-pid (issue #84): dead-worker detection -- the tailer marks live.json
# (worker_dead) + stops itself when pi is gone and the session has been
# quiet past the grace (the lost-terminal path). The normal path kills the
# tailer below before the grace can elapse, so it never fires there.
python3 "$PARSE_SESSION" --watch "$SESS_DIR" \
  --match "fleetwork-$T" --interval 20 --out "$ART/live.json" --pi-pid "$PI" \
  2>>"$ART/tailer.log" &
TAILER=$!

fwd_at=""
fwd_sig=""
on_stop() {
  [ -n "$fwd_at" ] && return
  fwd_at=$(date +%s)
  fwd_sig="${1:-15}"
  kill -TERM "$PI" 2>/dev/null || true
}
trap on_stop TERM
trap on_stop INT

# Wait on pi; a trapped TERM/INT interrupts wait, we forward to pi, give it
# 30s, then kill -9 (spec section 3.2 step 6). The rc comes from the loop's
# own wait: a second wait on the already-reaped pid returns 127, not the
# child's status.
RC=0
while :; do
  wait "$PI"
  RC=$?
  kill -0 "$PI" 2>/dev/null || break
  if [ -n "$fwd_at" ] && [ $(( $(date +%s) - fwd_at )) -ge 30 ]; then
    kill -9 "$PI" 2>/dev/null || true
  fi
done

# warden finding 6/9 (the t16 class): a forwarded stop signal makes the
# run signal-killed, not a clean exit. pi may have handled the forwarded
# TERM and exited 0 — in that case the unit would read clean and the G6
# empty-final override (rc 0 only) would misclassify the stop. Exit
# 128+<sig> instead: the executor's map_state maps exit-code 129..165
# to unclean/signal-<n> (the same class as a direct signal death), and
# the G6 block never runs.
if [ -n "$fwd_at" ] && [ "$RC" -eq 0 ]; then
  RC=$(( 128 + fwd_sig ))
fi

# Session jsonl into $ART (the 700-home wall, t46): /home/<agent> is 700 —
# the (hallmon) executor cannot traverse it to parse the session file pi
# left in $SESS_DIR. This post-exit copy is the executor's first parse path
# ($ART/session.jsonl); the home glob stays its permanent fallback for runs
# this wrapper generation never copied. Best-effort: a cp failure warns to
# the tailer log, never changes the exit code.
SESS_FILE=$(find "$SESS_DIR" -maxdepth 1 -name "*_fleetwork-$T.jsonl" -print -quit 2>/dev/null)
if [ -n "$SESS_FILE" ]; then
  if ! cp -f "$SESS_FILE" "$ART/session.jsonl" 2>>"$ART/tailer.log"; then
    echo "[session] copy to $ART/session.jsonl failed" >>"$ART/tailer.log"
  fi
fi

# G6 (issue #115): terminal asserts — a clean pi exit (rc 0) is not
# success without evidence. W5 (P8/F109, op ruling (b)): the wrapper
# REFUSES an empty final — the last assistant message
# empty/whitespace-only (or absent, parsed by the session tailer's own
# parser, one-shot over the complete session file) is the distinct
# empty_final terminal state (the executor's map_state maps the
# marker), never a clean success/completed even when work was written
# (F109: 10+ silent 200s read completed; the record alone could not
# say the work landed). The dispatch-named artifact
# ($ART/expected_artifact, worktree-relative) missing/empty is
# artifact-missing (it wins over empty-final when it fires). The
# dirty-no-commit gate (issue #81) still runs when neither did. The
# override reason goes to $ART/terminal (the daemon's map_state maps
# it); the wrapper exit code stays pi's (the marker, not
# the code, carries the reason). Absent marker = pre-G6 behavior.
G6_REASON=""
if [ "$RC" -eq 0 ]; then
  SESS_SRC="$ART/session.jsonl"
  [ -s "$SESS_SRC" ] || SESS_SRC="$SESS_FILE"
  # W5 (P8/F109): the empty-final decision builds on the session tailer's
  # own parser (parse_session.py, #171 — the same module the live tailer
  # ticks and the executor's one-shot parse uses; one parser, no forked
  # extraction): a one-shot parse of the COMPLETE session file (pi has
  # exited; the live.json 20s tick may lag the final message) reads
  # final_text — the last assistant message's text (whitespace-collapsed,
  # capped); None = empty/whitespace-only final or no final message at
  # all. A parse failure (unreadable/invalid session) degrades to empty:
  # an unverifiable final is refused like an empty one (never a clean
  # success — the marker is downgrade-only, the fail-loud posture).
  FINAL_TEXT=""
  if [ -n "$SESS_SRC" ] && [ -s "$SESS_SRC" ]; then
    FINAL_TEXT=$(python3 - "$PARSE_SESSION" "$SESS_SRC" <<'PYEOF' 2>/dev/null || true
import importlib.util, sys
if len(sys.argv) > 1:
    spec = importlib.util.spec_from_file_location("parse_session", sys.argv[1])
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    try:
        print(mod.parse_session_file(sys.argv[2]).get("final_text") or "")
    except mod.ParseError:
        pass
PYEOF
)
  fi
  WRITTEN=""
  GITWT=""
  if [ -n "$(git -C "$WT" rev-parse --git-common-dir 2>/dev/null)" ]; then
    GITWT=1
    # the wrapper's own $ART (.fleetwork) is untracked in a fresh worktree
    # (brief/piargs/gitenv) — exclude it, or the gate would always pass.
    if [ -n "$(git -C "$WT" status --porcelain -- . ':(exclude).fleetwork' 2>/dev/null)" ]; then
      WRITTEN=1
    fi
  elif [ -n "$(find "$WT" -path "$ART" -prune -o -type f -print 2>/dev/null | head -n 1)" ]; then
    WRITTEN=1
  fi
  if [ -s "$ART/expected_artifact" ]; then
    EA=$(cat "$ART/expected_artifact")
    [ -s "$WT/$EA" ] || G6_REASON="artifact-missing"
  fi
  # W5 (P8/F109, op ruling (b)): unconditional empty-final refusal — the
  # final message alone decides (the written-artifact escape hatch is
  # gone: an empty final with work written must not hide in completed).
  # artifact-missing (the named artifact) wins when it fired; the
  # dirty-no-commit gate below still runs when neither did.
  if [ -z "$G6_REASON" ] && [ -z "$FINAL_TEXT" ]; then
    G6_REASON="empty-final"
  fi
  # dirty-no-commit (issue #81, the ok-completion T22 class, t263): a
  # clean exit with a dirty tree and no commit since the worktree's
  # base — the work would sit uncommitted in the worktree (7-day GC)
  # while the terminal reads completed + a no-op branch-ref push
  # (head == base). The marker downgrades the terminal (map_state:
  # failed/dirty-no-commit) and rides SALVAGE_REASON (the worktree tar
  # -> the salvage ref, the same mechanism as the timeout path).
  # $ART/base_commit: prepare's handoff (the commit the worktree was
  # created at); absent = skip (back-compat: a run prepared before the
  # handoff shipped, or a non-git run).
  if [ -z "$G6_REASON" ] && [ -n "$GITWT" ] && [ -s "$ART/base_commit" ]; then
    BASE_COMMIT=$(cat "$ART/base_commit" 2>/dev/null)
    HEAD_NOW=$(git -C "$WT" rev-parse HEAD 2>/dev/null)
    if [ -n "$BASE_COMMIT" ] && [ "$HEAD_NOW" = "$BASE_COMMIT" ] && [ -n "$WRITTEN" ]; then
      G6_REASON="dirty-no-commit"
    fi
  fi
  if [ -n "$G6_REASON" ]; then
    printf '%s\n' "$G6_REASON" > "$ART/terminal"
  fi
fi

# detpipe (issue #130): the deterministic run-end handoff artifact — a
# zero-LLM pure function of (session, brief, worktree) (deploy/fleetwork/
# detpipe/; the schema is jarate's docs/DETERMINISTIC-PIPING.md, the
# detpipe/1 handoff.md + handoff.json sha256 sidecar). WARN-ONLY: a
# generator failure (missing python3/detpipe, a parse problem) must never
# block the salvage — the wrapper's exit code stays pi's, and the
# handoff.md/handoff.json in $ART ride the salvage tar when present.
if [ -s "$ART/session.jsonl" ] && [ -f "$DETPIPE" ]; then
  python3 "$DETPIPE" --session "$ART/session.jsonl" --brief "$ART/brief" \
    --worktree "$WT" --out "$ART/handoff.md" --json "$ART/handoff.json" \
    2>>"$ART/tailer.log" || echo "[detpipe] handoff generation failed (warn-only)" >>"$ART/tailer.log"
fi

# llm-capture (F109, issue #170): the client-side capture of the final LLM
# response — http status/body/headers/ttft/total tokens/model/endpoint; for
# empty finals the raw stream tail (last 20 events / 16KB, the
# discriminator payload). The module (deploy/fleetwork/llm_capture.py,
# stdlib-only) is fail-open (never exits non-zero); this block is
# WARN-ONLY too: a capture failure (missing python3/module) never blocks the
# salvage — the wrapper's exit code stays pi's, the warn rides $ART/tailer.log,
# and the capture rides the salvage tar when present. FLEETWORK_LLM_CAPTURE:
# hermetic-test override (the CI wrapper tests point it at a scratch tree);
# the default is the production path (the deploy lane installs it next to
# this directory).
LLM_CAPTURE="${FLEETWORK_LLM_CAPTURE:-/usr/local/lib/fleetwork/llm_capture.py}"
if [ -f "$LLM_CAPTURE" ]; then
  python3 "$LLM_CAPTURE" --session "$ART/session.jsonl" \
    --sidecar "$ART/llm-stream.json" --out "$ART/llm-capture.json" \
    --ticket "$T" 2>>"$ART/tailer.log" \
    || echo "[llm-capture] capture failed (warn-only)" >>"$ART/tailer.log"
fi

# Salvage (G6 (c), issue #115; the F83 crash salvage, superset): ANY
# non-succeeded terminal — a non-zero pi exit, a stop signal (budget /
# cancel), or the G6 override marker — tars the worktree (untracked
# files included; .git/node_modules/.venv/__pycache__ excluded for
# size) + the session + a manifest, wraps the tar in a commit, and
# points refs/heads/fleetwork-salvage/<ticket> on the bare mirror at
# it (durable: the ref survives the worktree's GC; the daemon's
# journal line + the api's 409 orphan scan find it). The ref stays a
# commit (update-ref rejects a bare blob under refs/heads/): the tar is
# the tree's single file (git show <ref>:salvage.tar).
# Salvage-phase identity: re-scope the wrapper's GIT_CONFIG_* (the agent
# identity sourced from $ART/gitenv — or nothing, pre-patch runs) to the
# neutral salvage identity for the remainder of the wrapper (salvage push +
# reap). Env config outranks all file config, so this also covers the
# config-level user.* resolution the old direct GIT_AUTHOR_*/GIT_COMMITTER_*
# exports did not (the env-scope gap, warden vehicle note 2026-10-20).
# Agent-attributed commits belong in the agent's own session, not in a crash
# handler (attribution finding 2026-10-20). One identity mechanism end to end: env.
GIT_CONFIG_COUNT=2
GIT_CONFIG_KEY_0=user.name
GIT_CONFIG_VALUE_0=fleetwork-salvage
GIT_CONFIG_KEY_1=user.email
GIT_CONFIG_VALUE_1=fleetwork-salvage@marzuki.local
export GIT_CONFIG_COUNT GIT_CONFIG_KEY_0 GIT_CONFIG_VALUE_0 GIT_CONFIG_KEY_1 GIT_CONFIG_VALUE_1

SALVAGE_REASON=""
[ "$RC" -ne 0 ] && SALVAGE_REASON="exit-$RC"
[ -n "$fwd_at" ] && SALVAGE_REASON="${SALVAGE_REASON:+$SALVAGE_REASON+}stop-signal"
[ -n "$G6_REASON" ] && SALVAGE_REASON="${SALVAGE_REASON:+$SALVAGE_REASON+}$G6_REASON"
if [ -n "$SALVAGE_REASON" ] && [ -d "$WT" ]; then
  BDIR=$(git -C "$WT" rev-parse --git-common-dir 2>/dev/null) || BDIR=""
  if [ -n "$BDIR" ] && [ -d "$BDIR" ]; then
    {
      echo "ticket: $T"
      echo "ts: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
      echo "rc: $RC"
      echo "stop_signal: ${fwd_at:-none}"
      echo "g6_reason: ${G6_REASON:-none}"
    } > "$ART/salvage-manifest.txt"
    TARBALL="$ART/salvage.tar"
    tar -cf "$TARBALL" --exclude=.git --exclude=node_modules \
      --exclude=.venv --exclude=__pycache__ -C "$WT" . 2>>"$ART/tailer.log" \
      || echo "[salvage] tar failed" >>"$ART/tailer.log"
    if [ -s "$TARBALL" ]; then
      BLOB=$(git -C "$WT" hash-object -w "$TARBALL" 2>>"$ART/tailer.log") || BLOB=""
      if [ -n "$BLOB" ]; then
        printf '100644 blob %s\tsalvage.tar\n' "$BLOB" | git -C "$WT" mktree > "$ART/salvage-tree" 2>>"$ART/tailer.log"
        GIT_AUTHOR_NAME=fleetwork-salvage GIT_AUTHOR_EMAIL=fleetwork-salvage@marzuki.local \
        GIT_COMMITTER_NAME=fleetwork-salvage GIT_COMMITTER_EMAIL=fleetwork-salvage@marzuki.local \
        git -C "$WT" commit-tree "$(cat "$ART/salvage-tree")" -m "salvage $T: $SALVAGE_REASON" > "$ART/salvage-commit" 2>>"$ART/tailer.log"
        if [ -s "$ART/salvage-commit" ]; then
          echo "[salvage] $SALVAGE_REASON: worktree+session tar -> refs/heads/fleetwork-salvage/$T"
          git -C "$BDIR" update-ref "refs/heads/fleetwork-salvage/$T" "$(cat "$ART/salvage-commit")" 2>&1 | sed 's/^/[salvage] /' || true
        fi
        rm -f "$ART/salvage-tree" "$ART/salvage-commit"
      fi
      rm -f "$TARBALL"
    fi
  fi
fi

# Reap step (always, if reached): make the session dir and file group-readable
# so the executor (hallmon, in fleetwork) can parse them. The agent owns both,
# so chgrp/chmod succeed from here.
chgrp fleetwork "$SESS_DIR" 2>/dev/null || true
chmod g+r "$SESS_DIR" 2>/dev/null || true
find "$SESS_DIR" -maxdepth 1 -name "*_fleetwork-$T.jsonl" -exec chmod g+r {} + 2>/dev/null || true

# Worktree ownership normalization for group cleanup (issue #47):
# tooling that chmods explicitly (pytest cacheprovider: path.chmod(0o777 - umask))
# clears the setgid bit inherited from the 2775 worktree root; children created
# after take the run's primary group (systemd-run --gid=<agent personal gid>),
# which the fleetwork cleanup lane (piboy sweep / hallmon GC) cannot write, so
# `git worktree remove --force` fails ENOTEMPTY. The wrapper runs as the agent
# (owner of its artifacts, member of fleetwork): chgrp + dir g+w. Hallmon-owned
# checkout files EPERM - expected and suppressed (they are already 2775/2770).
chgrp -R fleetwork "$WT" 2>/dev/null || true
find "$WT" -type d -exec chmod g+w {} + 2>/dev/null || true

# Kill the tailer: it must not outlive the main process or the unit would
# stay active after pi is done.
kill "$TAILER" 2>/dev/null || true
wait "$TAILER" 2>/dev/null || true

exit "$RC"
