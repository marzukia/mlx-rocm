# t1082 exec-cache replay fix — report

Date: 2026-11-01. Machine: guest VM (RX 9070 XT / gfx1201, ROCm 10.1 guest userland). Model: Qwen3-9B (GDN linear attention). Base: `2582cae` (4 KB value/zero slot wrappers; PR base = main `da9eeca` — verified ancestor of the head, `5254793` is not). Branch: `t1082-exec-replay-fix`.

## The fault family (pre-fix)

- r47 (256 B wrappers): capture OK, first replay OK, the second replay faulted (HSA_STATUS_ERROR_MEMORY_FAULT in `gather_rows_kernel`, faulting address ~38 GB below the arena). Root cause: a 2 KB gather row (512 x int32) written into its 256 B arena chunk overflowed into the adjacent chunk, which held the 1-element idx buffer shared by three fast_rows gathers; the next replay read the row's float bits as an index.
- r50 (4 KB wrappers, K3 out/idx routing without the zero-clear): the zero slot (the idx buffer's VA) was clobbered by an 8 KB step buffer before the first replay; the gather read a huge negative index (same fault class).
- r51 (K3 + pre-launch zero-clear): the gather fault cleared, exposing the next in-graph clobber: `copy_gg_dynamic_nd` (aperture violation, code 0x29) — its dynamic offset-in buffer (the zero-slot VA, 0x…9000) was written by an 8 KB step buffer earlier in the graph.

Common root cause: with the 5 slot wrappers (0x5000..0x9FFF) cached across steps, the per-step arena re-allocations restarted at 0x5000 and aliased the slot region, so any step buffer (gather row, dyn offset target) landed on top of a slot value the graph later read.

## The fix (this branch)

All in `mlx/backend/rocm/`:

1. **`eval.cpp` (`gd_step_prepare`)**: when the slots are cached (the arena already exists), the 5 reserved wrappers are not consumed by slot allocation; reserve 5 more so the step layout is identical to the first capture step (slots fresh, starting at 0xA000). The VAs the graph baked in stay valid at replay, and step buffers no longer alias the slot region.
2. **`indexing.hip` (`Gather::eval_gpu`, K3)**: in graph decode mode a gather output of <= 4 KB is routed to the persistent value slot 3, each row at a distinct 256 B-aligned offset (per-step cursor, so rows do not clobber each other in-graph — a decode step has several fast_rows gathers). The fast_rows index is read from the zero slot (zero-cleared before every launch by `g1_prelaunch_slot_h2d`). Outputs > 4 KB keep the stable-address arena buffer (the row fits its own block there).
3. **`allocator.{h,cpp}`**: `decode_value_slot3_cursor(size)` — the per-step cursor into slot 3 (reset with the arena, returns the 4 KB capacity when a row does not fit, the caller falls back to a stable-arena buffer).
4. **`device.cpp`** (already in the base): pre-launch zero-slot clear.
5. **`device.{cpp,h}`** (16-node re-delivery): at capture, record each in-graph H2D memcpy node's (host_src, dev_dst, bytes) and neutralize it (0-byte copy) so it cannot overwrite the pre-launch-delivered value mid-graph with a stale one; re-deliver the recorded values on the launch stream immediately before every `hipGraphLaunch` (same pattern as `g1_prelaunch_slot_h2d`). The record hook runs on the source graph BEFORE the exec is (re)instantiated, so the instantiated exec carries the neutralized nodes.

The per-step host H2D of the idx array still targets the original step buffer; only the kernel argument is redirected to the zero slot (and only for `n_rows == 1` fast_rows gathers — the zero slot is zero-cleared only for its first element; an n_rows>1 gather keeps the original idx buffer, so an eager T>1 step in a session with an active arena cannot read idx[1..] from the never-cleared part of the 4 KB zero-slot wrapper).

## Verification (guest VM, post-fix)

Wheel identity (a doc inaccuracy flagged by t1097 and corrected here): the runs in this section ran on the older `dist-t1074a44` wheel (pre-1cf60ec, predating the 16-node record_neutralize). They therefore evidence the K3 + slot-wrapper + cached-slot-reserve fix, not the re-delivery; the runs on the current wheel are in the next section.

- 6-step probe (dist-t1074a44 wheel): 0 HSA_STATUS_ERROR lines, all steps including the second replay complete; the [g1t] dump shows the three fast_rows gathers at distinct slot-3 offsets (0x8000/0x8100/0x8200), each row consumed from its own VA.
- 3 consecutive graph runs byte-identical (dist-t1074a44 wheel; pre-fix: run-nondeterministic — 1 of 3 matched eager, 2 of 3 degenerated to the 271 attractor). The per-launch slot-1 readback verifies dev==host.
- A/B bench 14-tok (dist-t1074a44 wheel): graph 26.20 tok/s (38.15 ms/step) vs eager 60.56 tok/s (16.51 ms/step) — a ~2.3x documented slowdown (per-launch slot H2D + 16-node re-delivery + zero-slot clear; CPU-side launch overhead). A finding, not a regression: the graph path is still correct and deterministic.
- 14-tok lossless gate (dist-t1074a44 wheel): graph = 271 x 56 (deterministic attractor), eager = 321 279 18483 ... (sane); graph != eager (the 271 attractor is a separate, pre-existing issue — see the K3 on/off A/B section; slot 1 is delivered correctly, dev==host, every launch).
- 4096-tok gate: OOM (HBM full on the 16 GB guest); a resource issue, not correctness.

## Verification (t1097, the current wheel)

Wheels (venv-m8, guest VM): `dist-t1097-1cf60ec2` (the clean 1cf60ec baseline, verified t1095-d=0, neutralize=2) and `dist-t1097-final` (this branch, post the 3690886 allocator revert).

- Dead-run probe (debug env = `MLX_G1_MEMDUMP=1` + `MLX_G1_H2DLOG=1`, N=6): PASS on both wheels — STEP 1-6 + ALLTOKS, byte-identical tokens 271 8160 513 760 0 0 (tokens 4+ nan = known pre-existing stale-replay behavior, not a regression; the 271-token degenerate attractor, isolated in the K3 on/off A/B section below).
- 14-token gate (clean env, GPROBE_N=14, dist-t1097-final): PASS — full stream, no `free(): invalid pointer`, no SEGV.
- [g1h] recorded lines quoted from the t1097 probe log (the 16-node re-delivery active in the dead-run probe, eight identical 8-byte staging values): `[g1h] recorded 0x78bdc9806000 <- 0x78c3e9cd8000 (8)`.

CI parity (host): `uv sync --locked`, `ruff format --check` (81 files OK), `ruff check` (all passed), `size_ratchet` (OK, 2 ratcheted), `pytest -m "not gpu"` (21 passed, 1 skipped).

## Post-fix state: fault-free and run-deterministic; two residual findings

The fault family is cleared (no HSA_STATUS_ERROR in any run; 120/120 steps complete in both gates) and the run-nondeterminism is closed: 3 of 3 consecutive graph runs are byte-identical (dist-t1074a44 wheel; on the current wheel the dead-run probe is byte-identical across dist-t1097-1cf60ec2 and dist-t1097-final, 271 8160 513 760 0 0). The pre-fix perturbation (partial NaN in the first replay's logits, warm region; run 1 self-heals by step 64, the other runs did not) is explained by the 16 in-graph H2D memcpy nodes that deliver per-step host staging values to one non-arena buffer (all 16 share the same dst — value slot 1 — paired 8-byte writes, nodes n116..n763): graph-H2D node delivery on this vGPU is known-unreliable (r15-r19 lineage — the reason the slot pre-launch H2D exists). The re-delivery (item 5) makes the device staging buffer hold the current host value before every graph launch, which is why the runs are now byte-identical.

Two residual findings:

1. **271-token degenerate attractor.** On the t1082 runs the 14-tok gate graph run degraded to 271 x 56 while eager stayed sane (321 279 18483 ...); the t1100 K3-on gate run was sane and the K3 on/off A/B section below isolates the behavior.
2. **4096-tok gate OOM.** HBM full on the 16 GB guest; a resource issue, not correctness.

## K3 on/off A/B (the 271-token attractor) — t1100, guest VM, 2026-11-01

Fresh wheel from this branch (fast files merged per the build note), venv-m8, fresh process per run, GPU-locked. 120-tok gate (56 steady-state tokens, ctx=14) + ggraph-probe (N=14 / 120):

- **K3 on (default):** eager baseline sane (`321 279 18483 ...`, 0 HSA errors); 120-tok gate sane (`321 279 18483 ...`, 0 HSA errors, RC=0); full N=120 probe completes all steps with 0 HSA errors (degenerate `271 8160 513 760 0 0 ...`, as on t1097); 14-tok probe `271 8160 513 760 0 0 ...`, 0 HSA errors.
- **`MLX_GD_K3IDXOFF=1` (zero-slot idx redirect off, out routing on):** 14-tok probe hard-faults — HSA_STATUS_ERROR_MEMORY_FAULT in `gather_rows_kernel` after step 3; 120-tok gate degenerates to `271 x 56` (no fault, RC=0).
- **`MLX_GD_K3OFF=1` (fully pre-K3):** 14-tok probe hard-faults after step 2; 120-tok gate `271 x 56`.

**Conclusion: the zero-slot idx redirect is not the cause of the 271 attractor — it masks a pre-existing bad idx.** With the redirect off (or K3 fully off), the same gathers fault (short run) or drive the long gate to a uniform 271 attractor; the bad idx is present with K3 fully off, so the root cause is upstream of the redirect (the t1097 stale-replay-input direction: the in-graph per-step H2D does not refresh these gathers' idx buffers at replay). The 271 attractor on short graph runs is the redirect converting a would-be OOB fault into a row-0 misread. **Recommendation: keep K3 as-is (it is the less-bad behavior and the clean 120-tok gate passes with it); next RCA step = trace the faulting gather's idx provenance at replay.**

**Build note (t1100):** the first t1100 compile exposed a latent name-resolution error introduced in the b8eae8e salvage (`gd_k3_off()`/`gd_k3_idxoff()` used unqualified in the enclosing namespace `mlx::core` while declared in `namespace mlx::core::rocm`); fixed by qualifying the two use sites.

## Disposition

Per the t1082 brief: the fix did not clear the "sane tokens, 2 consecutive runs" criterion (second replay is fault-free; tokens stable in 1 of 3 runs), so this is the one follow-up cycle. Salvage ref = `t1082-exec-replay-fix` pushed to the mirror (`/srv/fleetwork/mlx-rocm.git`); that no-PR line predates PR #3, which now heads from this branch (this round is the PR #3 fix round).

Guest-tree diagnostic patches (probe tree only, not part of this branch's diff except where mirrored in the repo): `device.cpp` pre-launch zero-slot clear (already in the repo), `eval.cpp` cached-slot reserve (now in the repo), `gd-gate4k.py` script fixes (`global PROMPT`; removed the 29k leftover lines in the 4k branch).
